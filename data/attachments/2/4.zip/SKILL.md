---
name: SQL Insight
version: v1.9.0
---

# SQL Insight
