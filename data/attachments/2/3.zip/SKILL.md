---
name: SQL Insight
version: v1.8.0
---

# SQL Insight
