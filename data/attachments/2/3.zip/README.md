# SQL Insight

版本：v1.8.0

由 SkillHub 演示用占位包构成。
