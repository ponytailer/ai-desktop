---
name: Lingo Bridge
version: v1.5.0
---

# Lingo Bridge
