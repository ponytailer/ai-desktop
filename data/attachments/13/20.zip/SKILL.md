---
name: Lingo Bridge
version: v1.4.0
---

# Lingo Bridge
