---
name: Meeting Brief
version: v3.1.0
---

# Meeting Brief
